# Changelog

## Unreleased

### Added
- Showrunner repository structure
- Book One workspace
- Canon and continuity system
- Series bible and mystery tracker
- Testament of Light archive
