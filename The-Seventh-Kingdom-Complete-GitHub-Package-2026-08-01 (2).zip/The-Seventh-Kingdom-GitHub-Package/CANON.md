# Canon Policy

## Canon Levels

1. **Locked Canon** — Explicitly approved by the author.
2. **Working Canon** — Guides current development but may change.
3. **Development Notes** — Ideas and alternatives that are not yet canon.

## Governing Rule

When files conflict, the latest author-approved manuscript chapter governs.

Record major changes in `CHANGELOG.md`.
