# Story Decisions — August 1, 2026

- GitHub is the official canon vault.
- Chat is the Writers' Room.
- The Seventh Kingdom is treated as a seven-book universe, not only a single novel.
- Book One remains titled *The Fifth Remnant*.
- The Story OS governs canon, theology, characters, mysteries, and adaptations.
- The Kingdom should function as a living reality within every chapter.
- The final scene of Book Seven remains open, but its final image should eventually be locked.
