# The Seventh Kingdom

A seven-book Christian speculative fiction series exploring faith, truth, memory, discipleship, artificial intelligence, human freedom, and the Kingdom of God under global technological control.

## Series

- **Book One:** *The Fifth Remnant*
- **Books Two–Seven:** In development

## Repository Purpose

This private repository contains the manuscript, canon, showrunner documents, world-building, theological framework, research, and adaptation materials for the series.

See `CANON.md` for the governing canon rules.
