# The Seven-Book Blueprint

## Book One — The Fifth Remnant
**Theme:** Gathering  
**Reader experience:** Waking up  
**Question:** Who remains faithful when truth becomes costly?  
**Series function:** Introduces the Remnant, ORACLE, the Consensus, the Testament, and the gathering of the Twelve.

## Book Two
**Theme:** Formation  
**Reader experience:** Learning to walk  
**Question:** How are disciples formed under surveillance?  
**Series function:** Establishes the Rule of Life, internal conflict, apprenticeships, and the cost of community.

## Book Three
**Theme:** Witness  
**Reader experience:** Learning to stand  
**Question:** What does truth cost?  
**Series function:** Expands the witness across nations and forces public testimony.

## Book Four
**Theme:** Perseverance  
**Reader experience:** Standing alone  
**Question:** Can the Fellowship endure persecution without becoming what it opposes?  
**Series function:** Fractures the movement, tests memory, and exposes false shepherds.

## Book Five
**Theme:** Judgment  
**Reader experience:** Watching Babylon crack  
**Question:** Can Babylon repent?  
**Series function:** The Consensus begins collapsing under contradictions it can no longer conceal.

## Book Six
**Theme:** Sacrifice  
**Reader experience:** Walking into sacrifice  
**Question:** What must be surrendered before victory?  
**Series function:** The Remnant faces irreversible losses and refuses a counterfeit triumph.

## Book Seven
**Theme:** Kingdom  
**Reader experience:** Seeing the King  
**Question:** Who truly reigns?  
**Series function:** Brings the saga to resurrection hope, inheritance, and the final exposure of every false kingdom.
