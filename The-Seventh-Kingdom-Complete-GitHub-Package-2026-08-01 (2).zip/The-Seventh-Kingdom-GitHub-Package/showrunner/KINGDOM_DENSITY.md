# Kingdom Density

Every chapter should contain at least one moment in which the Kingdom quietly advances.

Examples:

- someone tells the truth,
- someone forgives,
- someone feeds another,
- someone prays,
- someone refuses to lie,
- someone chooses mercy,
- someone accepts responsibility,
- someone recognizes the dignity of an enemy.

The Kingdom is not merely discussed. It is encountered.
