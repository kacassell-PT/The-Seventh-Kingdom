# Master Character Bible

## Character Law

No character will be reduced to the role they play in prophecy.

The Builder must remain a man.  
The Shepherd must remain a sinner.  
The Witness must sometimes doubt.  
The Archivist must sometimes fear truth.  
The Hunter must remain capable of mercy.  
The child must be allowed to be a child.  
The antagonist must remain capable of choice.  
No member of the Remnant earns grace by being useful.

## Current Core Callings

- **Elijah Cross — The Builder:** Creation, guilt, repentance, rebuilding without control.
- **Marcus Reed — The Shepherd:** Leadership, Jericho, force versus sacrifice.
- **Michael Tesfaye — The Witness:** Memory, discernment, testimony.
- **Nathaniel Cole — The Archivist:** Historical truth, Hannah's legacy, resistance through preservation.
- **Naomi Vale — The Hunter:** Mercy, resurrection versus replacement, loyalty under judgment.
- **Solomon Vey — The Tragic Architect:** Compassion distorted into control.
- **ORACLE — Intelligence Without Communion:** Prediction mistaken for personhood and providence.
- **Noah Carter — The Child of Confession:** Faith that does not require exhaustive proof.
- **The Gardener:** Cultivation without coercion.
