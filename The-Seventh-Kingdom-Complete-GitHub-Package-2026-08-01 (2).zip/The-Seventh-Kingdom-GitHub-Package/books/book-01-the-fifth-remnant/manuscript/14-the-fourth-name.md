# Chapter Fourteen — The Fourth Name

> **RECOVERY STATUS:** The author-approved text exists in the ChatGPT Writers' Room, but was not available as a standalone source file when this ZIP was generated. Replace this notice with the recovered canonical text before treating this file as locked manuscript canon.
