# Series Style Guide

## Tone

- Prophetic but human
- Cinematic and restrained
- Theologically serious without becoming preachy
- Emotionally grounded
- Suspense driven by moral choices

## Guardrails

- God is never reduced to an algorithm, metaphor, or impersonal force.
- Human beings retain moral responsibility.
- Technology may amplify sin or service but cannot replace redemption.
- The Kingdom of God is not equivalent to political or technological power.
