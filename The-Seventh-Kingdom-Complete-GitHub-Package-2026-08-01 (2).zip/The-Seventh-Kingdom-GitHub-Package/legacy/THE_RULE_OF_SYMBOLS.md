# The Rule of Symbols

## Water
Surrender, cleansing, passage, baptism, and realities beyond computation.

## Fire
Revelation, Pentecost, purification, and the light that reveals rather than flatters.

## Trees
Patient growth, cultivation, inheritance, and the Gardener's way.

## Stone
Witness, remembrance, covenant, and testimony that survives violence.

## Bread
Communion, hospitality, provision, and strangers becoming family.

## Light
ORACLE generates artificial illumination. Christ brings revealing light. Readers should feel the difference before it is explained.

## The Table
Communion over control; the Kingdom's central civilizational image.
