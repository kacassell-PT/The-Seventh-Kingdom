# Creative Constitution

## Story Laws

- Characters come before ideology.
- The Gospel is demonstrated before it is explained.
- Technology is never the villain; human worship, fear, and choice govern its use.
- Every antagonist believes they are saving something.
- Every major character must change.
- Every chapter must advance story, reveal character, or illuminate the Kingdom.
- The strongest chapters accomplish all three.
- No character exists only to prove the author right.
- Evil must never be more imaginative than goodness.
- Violence may restrain evil, but it cannot redeem people.
- The Fellowship may fail; the Kingdom does not.
- The audience must be trusted.
