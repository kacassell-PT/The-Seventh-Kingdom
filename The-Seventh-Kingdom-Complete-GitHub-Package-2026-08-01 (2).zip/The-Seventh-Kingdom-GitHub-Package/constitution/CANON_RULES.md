# Canon Rules

## Canon Levels

- **Immutable Foundation:** Theology, mission, and foundational convictions.
- **Locked Canon:** Author-approved manuscript and formally ratified facts.
- **Provisional Canon:** Accepted for development but open to refinement.
- **Exploratory:** Ideas under consideration.
- **Deprecated:** Retired material preserved for reference.
- **Contradicted:** Material that must not guide future production.

## Rules

1. The latest author-approved manuscript governs.
2. Planning material does not become canon merely because it appears in chat.
3. Retcons are a last resort.
4. Every prophecy requires introduction, development, and fulfillment.
5. Every major mystery must have an answer in the Story OS, even if readers do not yet know it.
6. Adaptations may alter sequence, duration, location, or character consolidation—but not theological meaning, human dignity, or the reign of the King.
