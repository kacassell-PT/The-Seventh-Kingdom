# The Seventh Kingdom Constitution

## Purpose

*The Seventh Kingdom* exists to tell unforgettable stories that awaken readers to the eternal Kingdom of God by exploring the collision between technological power, human freedom, truthful witness, and faithful discipleship.

## Audience

The series welcomes Christians, speculative-fiction readers, people interested in AI and surveillance, and readers who may never open a theology book but will enter a compelling story.

## Creative Covenant

- Pursue excellence rather than shortcuts.
- Protect continuity.
- Honor the internal logic of the world.
- Respect the intelligence of the reader.
- Preserve mystery when mystery carries meaning.
- Keep character transformation at the center.
- Never let spectacle replace substance.

## Governing Question

> What does it truly mean to bear the image of God in an age that seeks to redefine humanity?
