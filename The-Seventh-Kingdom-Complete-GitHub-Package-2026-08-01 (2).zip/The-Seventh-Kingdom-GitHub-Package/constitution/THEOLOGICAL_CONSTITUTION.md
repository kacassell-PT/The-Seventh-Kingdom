# Theological Constitution

1. God remains sovereign over history.
2. Every person bears the image of God.
3. Truth exists independent of power.
4. Redemption is personal and relational.
5. Freedom is essential to love.
6. Hope rests in God's promises, not human predictions.
7. The Kingdom advances through faithful witness, not coercion.
8. Resurrection is not replication.
9. Technology can serve healing but cannot become salvation.
10. Christ is not inserted into the story; the story exists inside His reality.
