# Values

1. Christ remains central.
2. Story before message.
3. Truth before spectacle.
4. Characters before ideology.
5. Redemption is costly.
6. Hope is realistic, not sentimental.
7. Technology is morally consequential, not inherently evil.
8. Every character possesses genuine moral agency.
9. Scripture illuminates rather than interrupts the narrative.
10. The Kingdom of God is the true protagonist of the saga.

## Founder's Creed

**Build with Truth.**

**Write with Beauty.**

**Protect the Canon.**

**Honor the King.**
